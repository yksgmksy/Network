#include "GameObject.h"
#include "Player.h"
#include "Arm.h"
#include "Map.h"
#include <list>

using namespace std;

bool Coll_Player_Tile(Player *player , Map *map)
{
	CollInfo playerCol = player->Collider();
	//list<Tile> mapList = map->ColliderList();

	for (auto i = map->mapTilesList.begin(); i != map->mapTilesList.end(); i++) {
		if ((*i).collider.rt.left < playerCol.rt.right) 
		if ((*i).collider.rt.right > playerCol.rt.left) 
		if ((*i).collider.rt.top < playerCol.rt.bottom) 
		if ((*i).collider.rt.bottom > playerCol.rt.top) {
			player->setIsGround(true);
			return true;
		}	
	}
	player->setIsGround(false);
	printf("%.2f  %.2f\n", player->pos.x , player->locate.y);
	return false;
	/*if ( playerCol.rt.left <  ){
		player->setIsGround(true);
	}
	else{
		player->setIsGround(false);
	}*/
}