#pragma once
#include "GameObject.h"
#include "Bitmap.h"
#include <list>
#include <stdint.h>

using namespace std;
enum {
	platformTile = 1,
	groundTile
};

class Tile
{
private:
	int posX;
	int posY;
	int size;  //ũ��
	int nomalSize; //���ڴ���
	int state; //����
	CBitmap bitmap;
	//�浹�ڽ�
public:
	CollInfo collider;
public:
	Tile();
	Tile(int _posX, int _posY, int _size, int _nomalSize, int _state) :posX(_posX), posY(_posY), size(_size), nomalSize(_nomalSize), state(_state) {}

	int getPosX() { return posX; }
	int getPosY() { return posY; }
	int getSize() { return size; }
	int getNomalSize() { return nomalSize; }
	int getState() { return state; }
	CBitmap getBitmap() { return bitmap; }
	void initTiles();
};

class Map : public GameObject
{
private:
	CBitmap bitmap;
	float angle;
	Vector2D scroll;
public:
	list<Tile> mapTilesList;
	
public:
	Map();
	Map(Vector2D initPos, Vector2D initDir);
	~Map();
	void init();
	void Update(float dt);
	void Render(HDC hdc, float dt);
	void Delete();
	list<Tile> ColliderList();

	void LoadTiles();
	Vector2D getBitMapSize();
	void camera(float moving);
};

