#include "WrappedWnd.h"
#include "PrepareWnd.h"

void settingWnd( CPrepareWnd& value );
void settingGame( );

CWrappedWnd::CWrappedWnd( ) : m_hWnd( nullptr ), m_hInstance( nullptr )
{
}

int CWrappedWnd::Loop( HINSTANCE hInstance, LPSTR lpCmdLine, int nCmdShow )
{
	m_hInstance = hInstance;

	CPrepareWnd value;

	value.hInstance = m_hInstance;
	value.nCmdShow = nCmdShow;

	settingWnd( value );

	this->registerWndClass( value );
	this->createWindow( value );
	this->showWindow( value );

	return this->MessageLoop( );
}

void CWrappedWnd::registerWndClass( const CPrepareWnd& value )
{
	WNDCLASSEX wcex = { 0, };

	wcex.cbSize = sizeof ( wcex );
	wcex.style = value.style;
	wcex.hInstance = value.hInstance;
	wcex.hCursor = value.hCursor;
	wcex.hbrBackground = value.hbrBackground;
	wcex.lpszClassName = value.lpszClassName;
	wcex.lpfnWndProc = value.lpfnWndProc;
	RegisterClassEx( &wcex );
}

void CWrappedWnd::createWindow( const CPrepareWnd& value )
{
	RECT rt;
	rt.left = value.X; rt.right = value.nHeight;
	rt.bottom = value.Y; rt.top = value.nWidth;
	m_hWnd = CreateWindow( 
		value.lpszClassName, value.lpWindowName, value.dwStyle, 
		value.X, value.Y, value.nWidth, value.nHeight,
		value.hWndParent, value.hMenu, value.hInstance, value.lpParam );
	//AdjustWindowRect(&rt, WS_OVERLAPPEDWINDOW, FALSE);
}

void CWrappedWnd::showWindow( const CPrepareWnd& value )
{
	ShowWindow( m_hWnd, value.nCmdShow );
	UpdateWindow( m_hWnd );
}

int CWrappedWnd::MessageLoop( )
{
	MSG msg;
	memset( &msg, 0, sizeof( msg ) );

	settingGame( );

	while( msg.message != WM_QUIT )
	{
		if( PeekMessage( &msg, nullptr, 0, 0, PM_REMOVE ) )
		{
			TranslateMessage( &msg );
			DispatchMessage( &msg );
		}
		else
		{
			this->ProcessingLoop( );
		}
	}

	return ( int )msg.wParam;
}

HWND CWrappedWnd::getWndHandle()
{
	return m_hWnd;
}

HINSTANCE CWrappedWnd::getInstanceHandle( )
{
	return m_hInstance;
}
