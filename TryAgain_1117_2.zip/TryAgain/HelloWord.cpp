#include "HelloWord.h"
#include "Bitmap.h"

static int x = 0, y = 0;

HelloWord::HelloWord( )
{
}

void HelloWord::create()
{
	Vector2D initpos(200, 200);
	Vector2D velocity(1, 0);
	player = new Player(initpos, velocity, ARROW_PLAYER_SPEED);
	map = new Map();
}

void HelloWord::initialize( )
{
	map->init();
	player->init();
	player->setCurrentMapSize(map->getBitMapSize());
}

void HelloWord::update( float dt )
{
	//object update
	player->Update(dt);
	map->Update(dt);

	//event
	float tmp = player->PlayerEvent(dt);
	map->camera(tmp);
	
	if (GetAsyncKeyState(VK_RETURN) && 0x8000)
	{
		g_framework = CGameFramework::getGameFramework();
		g_framework->getSceneManager()->registerScene(new Scene2);
		g_framework->getSceneManager()->reservedScene();
	}
}

void HelloWord::render( HDC hdc, float dt )
{
	map->Render(hdc, dt);

	//player�� ī�޶󰡵Ǳ� ���� ������ �ڵ鰪
	player->setWindowHWND(getWindowHWND());
	player->Render(hdc,dt);
}

void HelloWord::clear( )
{
}

void HelloWord::destroy( )
{
	player->Delete();
	map->Delete();
}