#include "set.h"

//#pragma comment(linker , "/entry:WinMainCRTStartup /subsystem:console")


void settingWnd( CPrepareWnd& value )
{
	value.lpWindowName = "network_project";
}

void settingGame( )
{
	g_framework = CGameFramework::getGameFramework( );

	g_framework->getSceneManager( )->registerScene( new HelloWord );
	g_framework->getSceneManager()->reservedScene();
}