#pragma once
#include "Scene.h"
#include "Scene2.h"
#include "set.h"

class HelloWord : public CScene
{
private:
	Player *player;
	Map *map;
public:

	HelloWord( );
	~HelloWord( ){};

	void					create( );

	void					initialize( );

	void					update( float dt );
	void					render( HDC hdc, float dt );

	void					clear( );

	void					destroy( );

public:



};

