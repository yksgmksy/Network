#include "Map.h"
#include "Bitmap.h"

Map::Map()
{
	locate.Zero();
	velocity.Zero();
}
Map::Map(Vector2D initPos, Vector2D initDir)
{
	locate = initPos;
	velocity = initDir;
	angle = 0;
}
Map::~Map()
{
}

void Map::init()
{
	scroll.Zero();
	bitmap.init("res/waitMap.bmp");
	LoadTiles();
	
}


void Map::Update(float dt)
{
	
}


void Map::Render(HDC hdc, float dt)
{
	bitmap.drawBitmap(hdc, scroll.x, scroll.y, 0, 0);

	for (auto i = mapTilesList.begin(); i != mapTilesList.end(); i++) {
		if (0 < (*i).getPosX() + scroll.x && 800 > (*i).getPosX() + scroll.x)
		(*i).getBitmap().drawBitmap(hdc, (*i).getPosX() + scroll.x, (*i).getPosY(), (*i).getSize(), (*i).getSize());
	}
}


void Map::Delete()
{

}

Vector2D Map::getBitMapSize()
{
	Vector2D size;
	size.x = bitmap.getBitmapInfo().bmWidth;
	size.y = bitmap.getBitmapInfo().bmHeight;
	return size;
}

void Map::LoadTiles() 
{
	int tmpx, tmpy;
	int _count;
	FILE* fp;
	while (!mapTilesList.empty())
		mapTilesList.pop_back();

	fp = fopen("tilemap/Stage1.txt", "rb");
	fscanf(fp, "%04d ", &tmpx);
	fscanf(fp, "%04d ", &tmpy);
	fscanf(fp, "%04d ", &_count);
	for (int i = 0; i < _count; i++)
	{
		int _posX;
		int _posY;
		int _size;
		int _nomalSize;
		int _state;
		
		fscanf(fp, "%04d ", &_posX);
		fscanf(fp, "%04d ", &_posY);
		fscanf(fp, "%02d ", &_size);
		fscanf(fp, "%02d ", &_nomalSize);
		fscanf(fp, "%02d ", &_state);
		Tile *tile = new Tile(_posX, _posY, _size, _nomalSize, _state);
		tile->initTiles();
		mapTilesList.push_back(*tile);
		delete tile;
	}

	fclose(fp);
}

void Map::camera(float moving)
{
	scroll.x = moving;
}

/////////////////////////////////////////////////////

void Tile::initTiles()
{
	if(this->getState() == platformTile)
		bitmap.init("res/platform.bmp");
	if (this->getState() == groundTile)
		bitmap.init("res/ground.bmp");
}