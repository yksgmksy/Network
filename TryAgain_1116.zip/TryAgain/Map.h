#pragma once
#include "GameObject.h"
#include "Bitmap.h"

class Map : public GameObject
{
private:
	CBitmap bitmap;
	float angle;
	Vector2D scroll;
public:
	Map();
	Map(Vector2D initPos, Vector2D initDir);
	~Map();
	void init();
	void Update(float dt);
	void Render(HDC hdc, float dt);
	void Delete();

	Vector2D getBitMapSize();
	void camera(float moving);
};