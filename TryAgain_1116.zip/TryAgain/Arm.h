#pragma once
#include "GameObject.h"
#include "Bitmap.h"

class Arm : public GameObject
{
private:
	CBitmap bitmap;
	float angle;
public:
	Arm();
	Arm(Vector2D initPos, Vector2D initDir);
	~Arm();
	void init();
	void Update(float dt);
	void Render(HDC hdc, float dt);
	void Delete();
	void ArrowPlayer(Vector2D playerPos) { playerPos.x -= 15;  locate = playerPos ; };
};