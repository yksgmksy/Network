#include "Arm.h"

Arm::Arm()
{
}
Arm::Arm(Vector2D initPos, Vector2D initDir)
{
	locate = initPos;
	velocity = initDir;
	angle = 0;
}
Arm::~Arm()
{
}

void Arm::init()
{
	bitmap.init("res/arm_arrow.bmp");
}


void Arm::Update(float dt)
{
	angle+= 0.1;
}


void Arm::Render(HDC hdc, float dt)
{
	bitmap.drawBitmapRotate(hdc, locate.x, locate.y, 0, 0, 0, angle);
}


void Arm::Delete()
{

}