#include "Map.h"
#include "Bitmap.h"

Map::Map()
{
	locate.Zero();
	velocity.Zero();
}
Map::Map(Vector2D initPos, Vector2D initDir)
{
	locate = initPos;
	velocity = initDir;
	angle = 0;
}
Map::~Map()
{
}

void Map::init()
{
	scroll.Zero();
	bitmap.init("res/waitMap.bmp");
}


void Map::Update(float dt)
{
	
}


void Map::Render(HDC hdc, float dt)
{
	bitmap.drawBitmap(hdc, scroll.x, scroll.y, 0, 0);
}


void Map::Delete()
{

}

Vector2D Map::getBitMapSize()
{
	Vector2D size;
	size.x = bitmap.getBitmapInfo().bmWidth;
	size.y = bitmap.getBitmapInfo().bmHeight;
	return size;
}

void Map::camera(float moving)
{
	scroll.x = moving;
}