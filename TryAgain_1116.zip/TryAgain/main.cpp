#include <windows.h>
#include <cstdio>
#include <vector>
#include "GameFramework.h"

int WINAPI WinMain( HINSTANCE hInstance, HINSTANCE hPrevIns, LPSTR lpCmdLine, int nCmdShow )
{
	return CGameFramework::getGameFramework( )->Loop( hInstance, lpCmdLine, nCmdShow );
}
