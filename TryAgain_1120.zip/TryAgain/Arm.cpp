#include "Arm.h"

Arm::Arm()
{
}
Arm::Arm(Vector2D initPos, Vector2D initDir)
{
	locate = initPos;
	dir = initDir;
	angle = 0;
}
Arm::~Arm()
{
}

void Arm::init()
{
	bitmap.init("res/arm_arrow.bmp");
	collider.type = box;
}


void Arm::Update(float dt)
{
	angle+= 0.1f;
}


void Arm::Render(HDC hdc, float dt)
{
	bitmap.drawBitmapRotate(hdc, (int)locate.x, (int)locate.y, 0, 0, 0, angle);
}

CollInfo Arm::Collider()
{
	collider.rt.left = (LONG)locate.x;
	collider.rt.right = (LONG)(locate.x + bitmap.getBitmapInfo().bmWidth);
	collider.rt.top = (LONG)locate.y;
	collider.rt.bottom = (LONG)(locate.x + bitmap.getBitmapInfo().bmHeight);
	return collider;
}

void Arm::Delete()
{

}