#include "GameObject.h"
#include "Player.h"
#include "Arm.h"
#include "Map.h"
#include <list>

using namespace std;

bool Coll_Player_Tile(Player *player , Map *map , float dt)
{
	CollInfo playerCol = player->Collider();
	//list<Tile> mapList = map->ColliderList();

	for (auto i = map->mapTilesList.begin(); i != map->mapTilesList.end(); i++) {
		
		//���������� üũ
		if (player->getState() == fall){
			if (player->pos.x + player->getSize().x / 2 > (*i).collider.rt.left &&
				player->pos.x + player->getSize().x / 2 < (*i).collider.rt.right &&
				player->pos.y + player->getSize().y > (*i).collider.rt.top &&
				player->pos.y + player->getSize().y < (*i).collider.rt.bottom){
				//�浹ó��
				player->collCorrection((int)(*i).collider.rt.top);
				return true;
			}
		}	
		//�� �߹ؿ� Ÿ���� �ִ��� üũ, ������ �߷��ۿ�
		//�÷��̾��� �� �� ��� ������ Ÿ�ϰ� �浹���
		if (player->getState() != fall){
			if (player->pos.x + player->getSize().x / 2 > (*i).collider.rt.left &&
				player->pos.x + player->getSize().x / 2 < (*i).collider.rt.right &&
				player->pos.y + player->getSize().y + 1 > (*i).collider.rt.top &&
				player->pos.y + player->getSize().y + 1 < (*i).collider.rt.bottom){
				
				printf("%.2f %.2f  %d\n", player->pos.x + player->getSize().x / 2, player->pos.y + player->getSize().y + 1, (*i).collider.rt.top);
				return true;
			}
		}
	}
	player->setIsGround(false);
	player->setState(fall);
	//player->Jump(dt);
	
	return false;
	/*if ( playerCol.rt.left <  ){
		player->setIsGround(true);
	}
	else{
		player->setIsGround(false);
	}*/
}