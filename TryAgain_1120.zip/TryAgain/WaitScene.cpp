#include "WaitScene.h"
#include "Bitmap.h"
#include "Coll.h"

static int x = 0, y = 0;

WaitScene::WaitScene( )
{
}

void WaitScene::create()
{
	Vector2D initpos(200, 200);
	Vector2D dir(1, 0);
	player = new Player(initpos, dir, ARROW_PLAYER_SPEED);
	map = new Map();
}

void WaitScene::initialize( )
{
	map->init();
	player->init();
	player->setCurrentMapSize(map->getBitMapSize());
}

void WaitScene::update( float dt )
{
	//coll 
	Coll_Player_Tile(player, map , dt);

	//event
	float tmp = player->PlayerEvent(dt);
	map->camera(tmp);

	//object update
	player->Update(dt);
	map->Update(dt);

	
	
	if (GetAsyncKeyState(VK_RETURN) && 0x8000)
	{
		g_framework = CGameFramework::getGameFramework();
		g_framework->getSceneManager()->registerScene(new Scene2);
		g_framework->getSceneManager()->reservedScene();
	}
}

void WaitScene::render( HDC hdc, float dt )
{
	map->Render(hdc, dt);

	//player�� ī�޶󰡵Ǳ� ���� ������ �ڵ鰪
	player->setWindowHWND(getWindowHWND());
	player->Render(hdc,dt);
}

void WaitScene::clear( )
{
}

void WaitScene::destroy( )
{
	player->Delete();
	map->Delete();
}