#pragma once
#include "Scene.h"
#include "Scene2.h"
#include "set.h"

class WaitScene : public CScene
{
private:
	Player *player;
	Map *map;
public:

	WaitScene( );
	~WaitScene( ){};

	void					create( );

	void					initialize( );

	void					update( float dt );
	void					render( HDC hdc, float dt );

	void					clear( );

	void					destroy( );

public:

	

};

