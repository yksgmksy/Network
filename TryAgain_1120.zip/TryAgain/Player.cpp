#include "Player.h"
#include "WrappedWnd.h"

Player::Player()
{
}
Player::Player(Vector2D initPos, Vector2D initDir,float speed)
{
	pos = initPos;
	locate = initPos;
	dir = initDir;
	this->speed = speed;
}
Player::~Player()
{
}

void Player::init()
{
	//player init
	bitmap.init("res/Player.bmp");
	this->fGravityreiteration = 0;
	state = fall;
	isGround = false;
	collider.type = box; // �浹Ÿ��
	setSize(bitmap);

	//arm init
	Vector2D armRotate(0,0);
	arm = new Arm(locate,armRotate);
	arm->init();
}


void Player::Update(float dt)
{
	//player

	if (this->state == jump || this->state == fall)
		Jump(dt);

	//printf("%.2f  %.2f  %d  %d  %.2f\n", pos.x, locate.y, getState(), isGround, fGravityreiteration);

	//arm updates
	arm->ArrowPlayer(locate);
	arm->Update(dt);
}


void Player::Render(HDC hdc, float dt)
{

	bitmap.drawRect(hdc, locate.x, locate.y, bitmap.getBitmapInfo().bmWidth, bitmap.getBitmapInfo().bmHeight);
	bitmap.drawBitmap(hdc,locate.x,locate.y,0,0);

	//SetWindowPos();

	arm->Render(hdc,dt);
}


void Player::Delete()
{

}

//call by scene
CollInfo Player::Collider()
{
	//���Ͻ�ũ��������
	pos.y = locate.y;
	collider.rt.left = pos.x;
	collider.rt.right = pos.x + bitmap.getBitmapInfo().bmWidth;
	collider.rt.top = pos.y;
	collider.rt.bottom = pos.y + bitmap.getBitmapInfo().bmHeight;
	return collider;
}

float Player::PlayerEvent(float dt)
{
	float scroll=0;

	//Ŀ�� ��ǥ
	GetCursorPos(&mousePoint);
	ScreenToClient(m_hWnd, (LPPOINT)&mousePoint);
	//printf("%.2f %.2f \t %.2f %.2f\n", pos.x, pos.x , locate.x , locate.y);

	if ( GetAsyncKeyState( VK_RIGHT ) & 0x8000 )
	{
		//�ǳ� ��
		if (pos.x >= curMapSize.x - WINDOW_WIDTH / 2){
			this->locate.x += speed * dt;
			this->pos.x = curMapSize.x + locate.x - WINDOW_WIDTH;
		}
		//ó�� ��
		else if (locate.x < WINDOW_WIDTH / 2){
			this->locate.x += speed * dt;
			this->pos.x = locate.x;
		}
		//��ũ���ʿ�
		else if (locate.x >= WINDOW_WIDTH / 2)	{
			this->locate.x = WINDOW_WIDTH / 2;
			this->pos.x += speed * dt;
			//�ʽ�ũ�Ѱ�����
			
		}
		
	}
	if ( GetAsyncKeyState( VK_LEFT ) & 0x8000 )
	{
		//�ǿ���
		if (pos.x <= WINDOW_WIDTH / 2){
			scroll += pos.x - locate.x;
			this->locate.x -= speed * dt;
			this->pos.x = locate.x;
		}
		//������
		else if (locate.x > WINDOW_WIDTH / 2){
			
			this->locate.x -= speed * dt;
			this->pos.x = curMapSize.x + locate.x - WINDOW_WIDTH;
		}
		else if (locate.x >= WINDOW_WIDTH / 2){
			this->locate.x = WINDOW_WIDTH / 2;
			this->pos.x -= speed * dt;
			//�ʽ�ũ�Ѱ�����
		}
	}
	if ( GetAsyncKeyState( VK_UP ) & 0x8000 )
	{
		if (this->isGround){
			this->fGravityreiteration = ARROW_PLAYER_JUMPPOWER;
			this->state = jump;
			this->isGround = !isGround;
		}
	}

	scroll = (float)locate.x - (float)pos.x;
	return scroll;
}

void Player::Jump(float dt)
{
	//gravity effect
	if( !this->isGround ){
		fGravityreiteration += GRAVITY * dt;
	}
	//jump
	this->locate.y += fGravityreiteration;

	//state check
	(fGravityreiteration >= 0)? this->state = fall : this->state = jump;

	//ground check (coll)
	/*if( this->locate.y >= 600 ){
		this->locate.y = 600;
		fGravityreiteration = 0.0f;
		this->isGround = true;
	}
	else{
		this->isGround = false;
	}*/
}

void Player::collCorrection(int top)
{
	//�������� 
	if (this->locate.y + bitmap.getBitmapInfo().bmHeight >= top){
		this->locate.y = top - bitmap.getBitmapInfo().bmHeight;
		this->isGround = true;
	}
	if (isGround){
		this->state = r_idle;
		this->fGravityreiteration = 0;
	}
}


void Player::FixClientCursor(POINT *p)
{
	p->x -= STARTWINDOW_X;
	p->y -= STARTWINDOW_Y;
}
