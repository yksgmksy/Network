#include "GameFramework.h"
#include "SceneManager.h"

CGameFramework::CGameFramework( ) : m_FrameInterval( 20 )
{
	prevFrameTime = GetTickCount();
	m_SceneManager = new CSceneManager;
}

CGameFramework::~CGameFramework( )
{
	delete m_SceneManager;
}

LRESULT CALLBACK CGameFramework::WndProc( HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam )
{
	//g_hWnd = hWnd;
	switch( message )
	{
		case WM_MOUSEMOVE:
			//SetWindowPos(hWnd, NULL, 300, 300, 500, 500, FALSE);
			break;
		case WM_DESTROY:
			PostQuitMessage( 0 );
			break;
	}

	return DefWindowProc( hWnd, message, wParam, lParam );
}

CGameFramework* CGameFramework::getGameFramework( )
{
	static CGameFramework frw;

	return &frw;
}

void CGameFramework::update( float dt )
{
	m_SceneManager->update( dt );
}

void CGameFramework::render( HDC hdc, float dt )
{
	HDC hMemDC;
	RECT windowRect;
	HBITMAP bitmap;

	GetClientRect( this->getWndHandle( ), &windowRect );

	hMemDC = CreateCompatibleDC( hdc );
	bitmap = CreateCompatibleBitmap( hdc, windowRect.right, windowRect.bottom );

	SelectObject( hMemDC, bitmap );
	FillRect( hMemDC, &windowRect, ( HBRUSH )1 );

	m_SceneManager->setWindowHWND(this->getWndHandle());
	m_SceneManager->render( hMemDC, dt );

	BitBlt( hdc, 0, 0, windowRect.right, windowRect.bottom, hMemDC, 0, 0, SRCCOPY );

	DeleteObject( bitmap );
	DeleteDC( hMemDC );
}

void CGameFramework::ProcessingLoop( )
{
	if( GetTickCount( ) - prevFrameTime > m_FrameInterval )
	{
		update( ( ( float )GetTickCount( ) - ( float )prevFrameTime ) / 1000.f );
			
		HDC hdc = GetDC( m_hWnd );

		render( hdc, ( ( float )GetTickCount( ) - ( float )prevFrameTime ) / 1000.f );

		ReleaseDC( m_hWnd, hdc );

		prevFrameTime = GetTickCount( );
	}
}

CSceneManager* CGameFramework::getSceneManager( )
{
	return m_SceneManager;
}

void CGameFramework::setFrameInterval( DWORD interval )
{
	m_FrameInterval = interval;
}

DWORD CGameFramework::getFrameInterval( )
{
	return m_FrameInterval;
}
