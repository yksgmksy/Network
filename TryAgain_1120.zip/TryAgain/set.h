#pragma once
#include "GameFramework.h"
#include "SceneManager.h"
#include "WaitScene.h"
#include "PrepareWnd.h"

static CGameFramework *g_framework;