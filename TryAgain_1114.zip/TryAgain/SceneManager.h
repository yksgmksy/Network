#pragma once

#include <Windows.h>
#include <string>
#include <stack>

class CScene;

using namespace std;
class CSceneManager
{
public:

	CSceneManager();
	~CSceneManager();

public:

	void					registerScene(CScene* scene);
	void					reservedScene();
	void					popScene();

public:

	void					update(float dt);
	void					render(HDC hdc, float dt);

private:

	stack<CScene*>	m_SceneContainer;

	CScene*					m_ReservedScene;
	CScene*					m_CurrentScene;

};
