#include "Arm.h"
#include "Bitmap.h"

Arm::Arm()
{
}
Arm::Arm(Vector2D initPos, Vector2D initDir)
{
	locate = initPos;
	velocity = initDir;
}
Arm::~Arm()
{
}

void Arm::init()
{

}


void Arm::Update(float dt)
{

}


void Arm::Render(HDC hdc, float dt)
{
	CBitmap bitmap("res/arm_arrow.bmp");
	bitmap.drawBitmap(hdc,locate.x,locate.y,0,0);
}


void Arm::Delete()
{

}