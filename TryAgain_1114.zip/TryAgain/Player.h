#pragma once
#include "GameObject.h"
#include "Arm.h"

enum {
	idle = 0,
	attact,
	jump,
	fall,
	hit
};

class Player : public GameObject
{
private:
	int state;
	float fJumpPower;
	float fGravityreiteration ;
	bool isGround;

	Arm *arm;
public:
	Player();
	Player(Vector2D initPos, Vector2D initDir);
	~Player();
	void init();
	void Update(float dt);
	void Render(HDC hdc, float dt);
	void Delete();
	void PlayerEvent(float dt);
	void Jump(float dt);
};