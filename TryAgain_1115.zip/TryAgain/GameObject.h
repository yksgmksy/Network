#pragma once

#include <stdio.h>
#include "Vector2D.h"
#include "Defines.h"

class GameObject 
{
public:
	Vector2D locate;
	Vector2D velocity;

	GameObject() ;
	~GameObject() ;

	virtual void init() = 0;
	virtual	void Update(float dt) = 0;
	virtual void Render(HDC hdc, float dt) = 0;
	virtual void Delete() = 0;
};