#pragma once
#include "GameObject.h"
#include "Arm.h"

enum {
	r_idle = 0,
	l_idle,
	attact,
	jump,
	fall,
	hit,
	r_run,
	l_run
};

class Player : public GameObject
{
private:
	int state;
	float fGravityreiteration ;
	bool isGround;
	POINT mousePoint;

	Arm *arm;
public:
	Player();
	Player(Vector2D initPos, Vector2D initDir);
	~Player();
	void init();
	void Update(float dt);
	void Render(HDC hdc, float dt);
	void Delete();
	void PlayerEvent(float dt);
	void Jump(float dt);
	void FixClientCursor(POINT *p);
};