#include "Player.h"
#include "Bitmap.h"

Player::Player()
{
}
Player::Player(Vector2D initPos, Vector2D initDir)
{
	locate = initPos;
	velocity = initDir;
}
Player::~Player()
{
}

void Player::init()
{
	//player init
	this->fGravityreiteration = ARROW_PLAYER_JUMPPOWER;
	state = fall;
	isGround = false;

	//arm init
	Vector2D armRotate(0,0);
	arm = new Arm(locate,armRotate);
}


void Player::Update(float dt)
{
	//player
	PlayerEvent(dt);

	if (this->state == jump || this->state == fall)
		Jump(dt);

	//arm updates
	arm->ArrowPlayer(locate);
	arm->Update(dt);
}


void Player::Render(HDC hdc, float dt)
{
	printf("state = %d \n",state);

	CBitmap bitmap("res/Player.bmp");
	bitmap.drawBitmap(hdc,locate.x,locate.y,0,0);

	arm->Render(hdc,dt);
}


void Player::Delete()
{

}

void Player::PlayerEvent(float dt)
{
	if ( GetAsyncKeyState( VK_RIGHT ) & 0x8000 )
	{
		this->locate.x += 50 * dt;
	}
	if ( GetAsyncKeyState( VK_LEFT ) & 0x8000 )
	{
		this->locate.x -= 50 * dt;
	}
	if ( GetAsyncKeyState( VK_UP ) & 0x8000 )
	{
		if( this->isGround )
			this->state = jump;
	}

	GetCursorPos(&mousePoint);
	FixClientCursor(&mousePoint);
	printf("%d %d\n", mousePoint.x, mousePoint.y);
}

void Player::Jump(float dt)
{
	this->isGround = false;
	
	//gravity effect
	if( !this->isGround ){
		fGravityreiteration += GRAVITY * dt;
	}
	//jump
	this->locate.y += fGravityreiteration;

	//state check
	(fGravityreiteration >= 0)? this->state = fall : this->state = jump;

	//ground check (coll)
	if( this->locate.y >= 700 ){
		this->locate.y = 700;
		fGravityreiteration = 0.0f;
		this->isGround = true;
	}
	else{
		this->isGround = false;
	}

	if( isGround ){
		this->state = r_idle;
		this->fGravityreiteration = ARROW_PLAYER_JUMPPOWER;
	}
}


void Player::FixClientCursor(POINT *p)
{
	p->x -= STARTWINDOW_X;
	p->y -= STARTWINDOW_Y;
}
