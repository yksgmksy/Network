#include "HelloWord.h"
#include "Bitmap.h"

static int x = 0, y = 0;

HelloWord::HelloWord( )
{
}

void HelloWord::create()
{
	Vector2D initpos(200, 200);
	Vector2D velocity(1, 0);
	player = new Player(initpos, velocity);
}

void HelloWord::initialize( )
{
	player->init();
}

void HelloWord::update( float dt )
{
	player->Update(dt);
	
	if (GetAsyncKeyState(VK_RETURN) && 0x8000)
	{
		g_framework = CGameFramework::getGameFramework();
		g_framework->getSceneManager()->registerScene(new Scene2);
		g_framework->getSceneManager()->reservedScene();
	}
}

void HelloWord::render( HDC hdc, float dt )
{
	player->Render(hdc,dt);
}

void HelloWord::clear( )
{
}

void HelloWord::destroy( )
{
	player->Delete();
}