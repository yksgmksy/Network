#pragma once

#include <Windows.h>

class CPrepareWnd;

class CWrappedWnd
{
protected:

	CWrappedWnd( );
	~CWrappedWnd( ){};

public:

	int						Loop( HINSTANCE hInstance, LPSTR lpCmdLine, int nCmdShow );

private:

	void					registerWndClass( const CPrepareWnd& value );
	void					createWindow( const CPrepareWnd& value );
	void					showWindow( const CPrepareWnd& value );
	int						MessageLoop( );

public:

	virtual void			ProcessingLoop( ) = 0;

protected:

	HWND					m_hWnd;
	HINSTANCE				m_hInstance;

public:

	void					setWndHandle( HWND hWnd );
	HWND					getWndHandle( );

	void					setInstanceHandle( HINSTANCE hInstance );
	HINSTANCE				getInstanceHandle( );

};
