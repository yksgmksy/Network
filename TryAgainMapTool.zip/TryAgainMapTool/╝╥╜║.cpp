#include <windows.h> // ������ ��� ����
#include <stdio.h>
#include <math.h>
#include "resource.h"
#include "Bitmap.h"
#include <list>
using namespace std;
HINSTANCE g_hInst;


struct BitmapPos {
	int x;
	int y;
	int tileSize;
};
struct DrawPos {
	int x;
	int y;
	int size;  //ũ��
	int nomalSize; //���ڴ���
	int state; //����
};

LPCTSTR lpszClass = L"CT Map Tool";

LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdParam, int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	HACCEL hAcc;
	
	g_hInst = hInstance;
	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH)GetStockObject(GRAY_BRUSH);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = hInstance;
	WndClass.lpfnWndProc = (WNDPROC)WndProc;
	WndClass.lpszClassName = lpszClass;
	WndClass.lpszMenuName = MAKEINTRESOURCE(IDR_MENU1);
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);
	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW, 100, 100, 970, 600, NULL, (HMENU)NULL, hInstance, NULL);
	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	while (GetMessage(&Message, 0, 0, 0))
	{
		
			TranslateMessage(&Message);
			DispatchMessage(&Message);

	}

	return Message.wParam;
}

float LengthPts(int x1, int y1, int x2, int y2)
{
	return (sqrt((float)(x1 - x2)*(x1 - x2) + (float)(y1 - y2)*(y1 - y2)));
}

BOOL InCircle(int x, int y, int mx, int my, int BSIZE)
{
	if (LengthPts(x + BSIZE, y + BSIZE, mx, my) < BSIZE)
		return				TRUE;
	else
		return				FALSE;
}

#define Width 16
#define Height 12

CBitmap platform;
CBitmap ground;
int mapWidth = 0;
int mapHeight = 0;
int width = 0;
int height = 0;
RECT windowRect;
BitmapPos platformPos;
BitmapPos groundPos;
int mouseClick = 0;
int **mapInfo;
bool bClick = false;
list<DrawPos> mapList;
LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	PAINTSTRUCT ps;
	HDC hdc, memdc;
	HBRUSH MyBrush, OldBrush;
	HBITMAP bitmap;
	
	HPEN MyPen, OldPen;
	
	
	int tileSize = 16;

	int mx, my;
	FILE* f;
	FILE* fp;

	switch (iMessage)
	{
	case WM_CREATE:
		platform.init("res/platform.bmp");
		ground.init("res/ground.bmp");

		mapWidth = 2229;
		mapHeight = 800;

		width = 2229 / tileSize;
		height = 800 / tileSize;

		platformPos.x = 50;
		platformPos.y = 850;
		platformPos.tileSize = 16;
		groundPos.x = 50 + tileSize * 3;
		groundPos.y = 850;
		groundPos.tileSize = 48;

		mapInfo = (int**)malloc(sizeof(int)*height);
		for (int i = 0; i < height; i++)
			mapInfo[i] = (int*)malloc(sizeof(int)*width);
		for (int i = 0; i < height; i++)
			for (int j = 0; j < width; j++)
				mapInfo[i][j] = 0;

		MoveWindow(hWnd, 100, 100, mapWidth , mapHeight+200 , 0);
		GetClientRect(hWnd, &windowRect);
		break;
	case WM_COMMAND:

		switch (LOWORD(wParam))
		{
			//�ҷ�����
		case ID_40002:
			int count;
			fp = fopen("Stage1.txt", "rb");
			while (!mapList.empty())
				mapList.pop_back();

			fscanf(fp, "%04d ", &mapWidth);
			fscanf(fp, "%04d ", &mapHeight);
			fscanf(fp, "%04d ", &count);
			for (int i = 0; i < count; i++)
			{
				DrawPos *dp = new DrawPos();
				fscanf(fp, "%04d ", &dp->x);
				fscanf(fp, "%04d ", &dp->y);
				fscanf(fp, "%02d ", &dp->size);
				fscanf(fp, "%02d ", &dp->nomalSize);
				fscanf(fp, "%02d ", &dp->state);
				mapList.push_back(*dp);
				delete dp;
			}
			fclose(fp);
			for (auto i = mapList.begin(); i != mapList.end(); i++) {
				mapInfo[(*i).y / (*i).nomalSize][(*i).x / (*i).nomalSize] = (*i).state;
			}

			break;
			//����
		case ID_40001:

			f = fopen("Stage1.txt", "wb");
			while(!mapList.empty())
			mapList.pop_back();
			for (int i = 0; i < height; i++)
			{
				for (int j = 0; j < width; j++)
				{
					if (mapInfo[i][j] != 0) {
						DrawPos *dp = new DrawPos();
						dp->x = j*tileSize;
						dp->y = i*tileSize;
						if(mapInfo[i][j]==1)
							dp->size = tileSize;
						else if (mapInfo[i][j] == 2)
							dp->size = tileSize*3;//3��
						dp->nomalSize = tileSize;//�⺻Ÿ�ϻ�����
						dp->state = mapInfo[i][j];
						mapList.push_back(*dp);
						delete dp;
					}
					//fprintf(f, " %02d ", mapcheck[i][j]);
				}
			}
			fprintf(f, "%04d %04d ", width*tileSize, height*tileSize);
			fprintf(f, "%04d ", mapList.size());
			for (auto i = mapList.begin(); i != mapList.end(); i++) {
				fprintf(f, "%04d %04d %02d %02d %02d ", (*i).x, (*i).y, (*i).size, (*i).nomalSize,(*i).state);
			}
			fclose(f);
			break;
		}
		InvalidateRect(hWnd, NULL, false);
		break;
	case WM_LBUTTONUP:
		bClick = false;
		break;
	case WM_RBUTTONDOWN:
		mx = LOWORD(lParam);
		my = HIWORD(lParam);
		mouseClick = 0;
		InvalidateRect(hWnd, NULL, FALSE);

		break;
	case WM_MOUSEMOVE:
		if (!bClick)break;
	case WM_LBUTTONDOWN:
		mx = LOWORD(lParam);
		my = HIWORD(lParam);
		bClick = true;
		if (mx > platformPos.x && mx < platformPos.x + platformPos.tileSize &&
			my > platformPos.y && my < platformPos.y + platformPos.tileSize)
			mouseClick = 1;
		else if (mx > groundPos.x && mx < groundPos.x + groundPos.tileSize &&
			my > groundPos.y && my < groundPos.y + groundPos.tileSize)
			mouseClick = 2;
		else if(mx > 0 && mx < width*tileSize &&
			my > 0 && my < height*tileSize)
			mapInfo[my / tileSize][mx / tileSize] = mouseClick;

		InvalidateRect(hWnd, NULL, false);
		break;
	
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		memdc = CreateCompatibleDC(hdc);
		GetClientRect(hWnd, &windowRect);
		bitmap = CreateCompatibleBitmap(hdc, windowRect.right, windowRect.bottom);
		SelectObject(memdc, bitmap);
		FillRect(memdc, &windowRect, (HBRUSH)1);

		MyPen = CreatePen(PS_SOLID, 1, RGB(255, 0, 0));
		OldPen = (HPEN)SelectObject(memdc, MyPen);
		if (mouseClick == 1)
		Rectangle(memdc, platformPos.x-1, platformPos.y - 1, platformPos.x + 17, platformPos.y+17);
		if (mouseClick == 2)
		Rectangle(memdc, groundPos.x - 1, groundPos.y - 1, groundPos.x + 49, groundPos.y + 49);

		MyPen = CreatePen(PS_SOLID, 1, RGB(0, 0, 255));
		OldPen = (HPEN)SelectObject(memdc, MyPen);
		for (int i = 0; i < height; i++)
		{
			for (int j = 0; j < width; j++)
			{
				Rectangle(memdc, j * tileSize, i * tileSize, j * tileSize + tileSize, i * tileSize + tileSize);
			}
		}

		for (int i = 0; i < height; i++)
		{
			for (int j = 0; j < width; j++)
			{
				if(mapInfo[i][j] == 1)
					platform.drawBitmap(memdc, j*tileSize, i*tileSize, platformPos.tileSize, platformPos.tileSize);
				if (mapInfo[i][j] == 2)
					ground.drawBitmap(memdc, j*tileSize, i*tileSize, groundPos.tileSize, groundPos.tileSize);
			}
		}
		//��Ʈ�ʱ׸�
		platform.drawBitmap(memdc, platformPos.x, platformPos.y, platformPos.tileSize, platformPos.tileSize);
		
		ground.drawBitmap(memdc, groundPos.x, groundPos.y, groundPos.tileSize, groundPos.tileSize);

		BitBlt(hdc, 0, 0, windowRect.right, windowRect.bottom, memdc, 0, 0, SRCCOPY);

		SelectObject(memdc, OldPen);
		DeleteObject(MyPen);  
		EndPaint(hWnd, &ps);

		DeleteDC(memdc);

		EndPaint(hWnd, &ps);
		break;

	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}

	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}